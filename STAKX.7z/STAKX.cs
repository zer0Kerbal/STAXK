﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STAKX
{
    public class STAKX
    {
    }
}

/*{
	"NAME" : "STatstical Analysis for Kerbal eXploration",
	"URL"      : "https://raw.githubusercontent.com/zer0Kerbal/STAKX/master/GameData/STAKX/STAKX.version",
	"DOWNLOAD" : "https://github.com/zer0Kerbal/STAKX/releases/latest",
	"GITHUB" :
	{
		"USERNAME" : "zer0Kerbal",
		"REPOSITORY" : STAKX
		"ALLOW_PRE_RELEASE": false
	},
	"VERSION" : 
	{
		"MAJOR" : 1,
		"MINOR" : 0,
		"PATCH" : 0,
		"BUILD" : 0
	},
	"KSP_VERSION":
	{
		"MAJOR":1,
		"MINOR":7,
		"PATCH":3
	},
	"KSP_VERSION_MIN":
	{
		"MAJOR":1,
		"MINOR":4,
		"PATCH":1
	},
	"KSP_VERSION_MAX":
	{
		"MAJOR":1,
		"MINOR":8,
		"PATCH":9999
	}
}*/
